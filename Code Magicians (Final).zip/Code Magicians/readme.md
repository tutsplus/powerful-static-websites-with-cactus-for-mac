# Cactus Example Blog

This is an example blog project for [Cactus](https://github.com/koenbok/Cactus). It provides a starting point for your own blog. Just download it, make sure you have [Cactus](https://github.com/koenbok/Cactus) installed and run `cactus serve`.

You can see it running [here](http://cactus-example-blog.s3-website-us-east-1.amazonaws.com/).